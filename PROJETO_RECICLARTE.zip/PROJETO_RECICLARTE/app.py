from flask import Flask, render_template, request, redirect, url_for, flash, session
import smtplib
import random
import os
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

app = Flask(__name__)
app.secret_key = os.urandom(24)

# Banco de dados simulado
users_db = {
    "guilhermevictorassissantana@gmail.com": {
        "password": "gnew cgle xhvi czty",
        "name": "Guilherme"
    }
}

# Armazenando códigos de recuperação temporários
recovery_codes = {}

# Página inicial (home)
@app.route('/')
def home():
    return render_template('index_tela_home.html')  # A tela home será a primeira página carregada

# Página de login
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')

        # Verifica se o email existe no banco de dados e se a senha está correta
        if email in users_db and users_db[email]['password'] == password:
            # Armazena o usuário na sessão
            session['user'] = email
            flash(f"Bem-vindo, {users_db[email]['name']}!", "success")
            return redirect(url_for('buscar_locais'))
        else:
            flash("Email ou senha incorretos. Tente novamente.", "error")
            return redirect(url_for('login'))  # Retorna à tela de login se falhar

    # Método GET: Renderiza o formulário de login
    return render_template('index.html')


    # Método GET: Renderiza o formulário de login
    return render_template('index.html')

# Rota para a tela de busca de locais
@app.route('/buscar-locais')
def buscar_locais():
    return render_template('index_tela_busca.html')

# Rota para o Ecoponto Itagara
@app.route('/index_tela_ecoponto_1')
def ecoponto_1():
    return render_template('index_tela_ecoponto_1.html')

# Rota para o Ecoponto Itapuã (novo)
@app.route('/index_tela_ecoponto_2')
def ecoponto_2():
    return render_template('index_tela_ecoponto_2.html')

# Rota para o Ecoponto Mané Dendê
@app.route('/index_tela_ecoponto_3')
def ecoponto_3():
    return render_template('index_tela_ecoponto_3.html')

# Rota para a tela de materiais
@app.route('/index_tela_materiais')
def tela_materiais():
    return render_template('index_tela_materiais.html')

# Rota para logout
@app.route('/logout')
def logout():
    session.pop('user', None)
    flash("Você saiu da sua conta.", "success")
    return redirect(url_for('home'))

# Rota de recuperação de senha
@app.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        if email in users_db:
            code = random.randint(1000, 9999)
            recovery_codes[email] = code
            send_email(email, code)
            session['recovery_email'] = email
            return redirect(url_for('confirm_code'))
        else:
            flash("E-mail não encontrado!", "error")
            return redirect(url_for('forgot_password'))
    return render_template('forgot_password.html')

# Rota para a tela de confirmação do código
@app.route('/confirm-code', methods=['GET', 'POST'])
def confirm_code():
    if request.method == 'POST':
        email = session.get('recovery_email')
        entered_code = request.form['code']

        if email and entered_code == str(recovery_codes.get(email)):
            session['code_confirmed'] = True
            return redirect(url_for('reset_password'))
        else:
            flash("Código inválido!", "error")
            return redirect(url_for('confirm_code'))

    return render_template('confirm_code.html')

# Rota para redefinir a senha
@app.route('/reset-password', methods=['GET', 'POST'])
def reset_password():
    if 'code_confirmed' not in session:
        flash("Confirme o código antes de redefinir sua senha.", "error")
        return redirect(url_for('forgot_password'))

    if request.method == 'POST':
        new_password = request.form['new_password']
        email = session.get('recovery_email')
        if email:
            users_db[email]['password'] = new_password
            session.pop('recovery_email', None)
            session.pop('code_confirmed', None)
            flash("Senha redefinida com sucesso! Agora você pode acessar a sua conta.", "success")
            return redirect(url_for('login'))

    return render_template('reset_password.html')

# Rota de cadastro (com redirecionamento para validação)
@app.route('/cadastro', methods=['GET', 'POST'])
def cadastro():
    if request.method == 'POST':
        # Redireciona para a tela de validação
        return redirect(url_for('validacao_cadastro'))

    return render_template('index_tela_cadastro.html')  # Tela de cadastro

# Rota de validação (tela intermediária antes do login)
@app.route('/validacao-cadastro')
def validacao_cadastro():
    return render_template('validacao_cadastro.html')  # Tela de validação antes do login

@app.route('/index_edicao_dados')
def edicao_dados():
    return render_template('index_edicao_dados.html')

@app.route('/index_tela_busca')
def tela_busca():
    return render_template('index_tela_busca.html')


# Função para enviar e-mail (simulação)
def send_email(to_email, code):
    from_email = "guilhermevictorassissantana@gmail.com"
    from_password = "gnew cgle xhvi czty"

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(from_email, from_password)

        subject = "Código de recuperação de senha"
        body = f"Seu código de recuperação é: {code}"
        message = MIMEMultipart()
        message['From'] = from_email
        message['To'] = to_email
        message['Subject'] = subject
        message.attach(MIMEText(body, 'plain'))

        server.sendmail(from_email, to_email, message.as_string())
        server.quit()

    except Exception as e:
        print(f"Erro ao enviar e-mail: {e}")

if __name__ == '__main__':
    app.run(debug=True)
