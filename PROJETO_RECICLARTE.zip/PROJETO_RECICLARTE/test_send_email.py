import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

from_email = "guilhermevictorassissantana@gmail.com"  # Substitua pelo seu e-mail
to_email = "guilherme30@ba.estudante.senai.br"  # E-mail para o qual você deseja enviar
password = "gnew cgle xhvi czty"  # Substitua pela sua senha ou senha de app gerada no Google

# Criação do servidor SMTP
server = smtplib.SMTP('smtp.gmail.com', 587)
server.starttls()  # Inicia a criptografia
server.login(from_email, password)  # Faz o login no servidor SMTP com seu e-mail e senha

# Criando a mensagem de e-mail com codificação UTF-8
subject = "Testando envio"  # Assunto do e-mail
body = "Este é um e-mail de teste com acento: á, é, í, ó, ú!"  # Corpo do e-mail (exemplo com caracteres especiais)

# Criação do objeto MIMEText para garantir a codificação UTF-8
message = MIMEMultipart()
message['From'] = from_email
message['To'] = to_email
message['Subject'] = subject

# Corpo do e-mail
message.attach(MIMEText(body, 'plain', 'utf-8'))

# Envia o e-mail
server.sendmail(from_email, to_email, message.as_string())  # Envia a mensagem formatada
server.quit()  # Encerra a conexão com o servidor SMTP

print("E-mail enviado com sucesso!")  # Confirma o envio do e-mail
